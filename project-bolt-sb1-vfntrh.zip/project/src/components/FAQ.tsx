import { motion } from 'framer-motion';
import { useState } from 'react';

const faqs = [
  {
    question: "Что такое SEO-оптимизация?",
    answer: "SEO-оптимизация — это комплекс мер по улучшению сайта для его ранжирования в поисковых системах. Это помогает привлечь больше органического трафика на ваш сайт."
  },
  {
    question: "Сколько времени занимает продвижение сайта?",
    answer: "Первые результаты можно увидеть через 3-4 месяца работы. Полноценное продвижение занимает от 6 месяцев до года, в зависимости от конкуренции и состояния сайта."
  },
  {
    question: "Какие гарантии вы предоставляете?",
    answer: "Мы предоставляем ежемесячные отчеты о проделанной работе и достигнутых результатах. Работаем по договору с четкими KPI."
  }
];

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Частые вопросы</h2>
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center"
                onClick={() => setActiveIndex(activeIndex === index ? null : index)}
              >
                <span className="font-medium">{faq.question}</span>
                <span className="transform transition-transform duration-200">
                  {activeIndex === index ? '−' : '+'}
                </span>
              </button>
              <motion.div
                initial={false}
                animate={{ height: activeIndex === index ? 'auto' : 0 }}
                className="overflow-hidden"
              >
                <p className="px-6 pb-4">{faq.answer}</p>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}